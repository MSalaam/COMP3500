public class CustomerModel {


    public int getCustomerID() {
        return customerID; }
    public void setCustomerID(int customerID) { this.customerID = customerID; }

    public String getCustomerName() {

        return customerName;
    }
    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public int getTotalItems() {
        return totalItems;}
    public void setTotalItems(int totalItems) {
        this.totalItems = totalItems;
    }

    public int customerID;
    public String customerName;
    public int totalItems;






}
