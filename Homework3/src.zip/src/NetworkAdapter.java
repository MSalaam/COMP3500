public class NetworkAdapter implements DataAccess{
    @Override
    public void connect() {

    }

    @Override
    public void saveProduct(ProductModel product) {

    }

    @Override
    public ProductModel loadProduct(int productID) {
        return null;
    }

    @Override
    public OrderModel loadOrder(int orderId) {
        return null;
    }

    @Override
    public void saveOrder(OrderModel order) {

    }

    @Override
    public CustomerModel loadCustomer(int customerId) {
        return null;
    }

    @Override
    public void saveCustomer(CustomerModel customer) {

    }
}
